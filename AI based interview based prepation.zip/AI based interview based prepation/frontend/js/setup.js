// ============================================================
// InterviewAI – Interview Setup Page JavaScript
// ============================================================

const config = {
  role: '',
  difficulty: 'Intermediate',
  type: 'Technical',
  qCount: '10',
  timeLimit: '120',
  mode: 'voice',
};

// Pre-fill from URL params
const params = new URLSearchParams(window.location.search);
if (params.get('role'))  config.role = params.get('role');
if (params.get('diff'))  config.difficulty = params.get('diff');
if (params.get('type'))  config.type = params.get('type');
if (params.get('mode'))  config.mode = params.get('mode');

// Job Roles data
const JOB_ROLES = [
  { label: 'Software Developer',  icon: 'fas fa-code' },
  { label: 'Frontend Developer',  icon: 'fas fa-paint-brush' },
  { label: 'Backend Developer',   icon: 'fas fa-server' },
  { label: 'Python Developer',    icon: 'fab fa-python' },
  { label: 'Data Analyst',        icon: 'fas fa-chart-pie' },
  { label: 'ML Engineer',         icon: 'fas fa-brain' },
  { label: 'Cloud Engineer',      icon: 'fas fa-cloud' },
  { label: 'DevOps Engineer',     icon: 'fas fa-network-wired' },
  { label: 'Cybersecurity',       icon: 'fas fa-shield-alt' },
  { label: 'App Developer',       icon: 'fas fa-mobile-alt' },
  { label: 'Database Admin',      icon: 'fas fa-database' },
  { label: 'System Analyst',      icon: 'fas fa-project-diagram' },
];

document.addEventListener('DOMContentLoaded', () => {
  // Build role cards
  const grid = document.getElementById('roleGrid');
  if (grid) {
    grid.innerHTML = JOB_ROLES.map(r => `
      <div class="role-card ${config.role === r.label ? 'selected' : ''}"
           onclick="selectRole('${r.label}', this)">
        <i class="${r.icon}"></i>
        <span>${r.label}</span>
      </div>`).join('');
  }

  // Set default selections from config
  syncPillSelections();
  syncModeSelection();
});

function selectRole(role, el) {
  config.role = role;
  document.querySelectorAll('.role-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
}

function selectOption(key, val, el) {
  config[key] = val;
  el.closest('.option-pills').querySelectorAll('.option-pill').forEach(p => p.classList.remove('active'));
  el.classList.add('active');
}

function selectMode(mode, el) {
  config.mode = mode;
  document.querySelectorAll('.mode-select-card').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
}

function syncPillSelections() {
  ['difficulty', 'type', 'qCount', 'timeLimit'].forEach(key => {
    const pill = document.querySelector(`.option-pill[data-val="${config[key]}"]`);
    if (pill) {
      pill.closest('.option-pills').querySelectorAll('.option-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
    }
  });
}

function syncModeSelection() {
  document.querySelectorAll('.mode-select-card').forEach(c => {
    c.classList.toggle('active', c.dataset.mode === config.mode);
  });
}

function nextStep(step) {
  // Validate step 1
  if (step === 2 && !config.role) {
    alert('Please select a job role to continue.');
    return;
  }

  // Update progress indicators
  for (let i = 1; i <= 4; i++) {
    const el = document.getElementById('spStep' + i);
    if (!el) continue;
    el.classList.remove('active', 'done');
    if (i < step) el.classList.add('done');
    if (i === step) el.classList.add('active');
  }

  // Update connector lines
  document.querySelectorAll('.sp-line').forEach((line, idx) => {
    line.classList.toggle('done', idx < step - 1);
  });

  // Show step content
  document.querySelectorAll('.setup-step-content').forEach(c => c.classList.remove('active'));
  const stepEl = document.getElementById('step' + step);
  if (stepEl) stepEl.classList.add('active');

  // Fill review
  if (step === 4) {
    document.getElementById('rev-role').textContent   = config.role;
    document.getElementById('rev-diff').textContent   = config.difficulty;
    document.getElementById('rev-type').textContent   = config.type;
    document.getElementById('rev-qcount').textContent = config.qCount + ' questions';
    document.getElementById('rev-time').textContent   = config.timeLimit === '0' ? 'No limit' : (config.timeLimit / 60) + ' min';
    document.getElementById('rev-mode').textContent   = config.mode.charAt(0).toUpperCase() + config.mode.slice(1) + ' Mode';

    // Show permission notice for voice/video
    const permNotice = document.getElementById('permNotice');
    if (permNotice) permNotice.style.display = (config.mode !== 'text') ? 'flex' : 'none';
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function launchInterview() {
  // Save config to session storage
  sessionStorage.setItem('interviewConfig', JSON.stringify(config));

  // Redirect to interview room
  window.location.href = 'interview.html';
}
