// ============================================================
// InterviewAI – Questions Route (Question Bank)
// ============================================================

const router = require('express').Router();
const authMW = require('../middleware/auth');

// Static question bank (can be moved to DB later)
const QUESTION_BANK = {
  'Software Developer': {
    Technical: {
      Beginner: [
        { id: 1, q: 'What is Object-Oriented Programming? Explain its four pillars.', tags: ['OOP','Basics'] },
        { id: 2, q: 'What is the difference between an array and a linked list?', tags: ['DSA','Basics'] },
        { id: 3, q: 'Explain what a RESTful API is and its principles.', tags: ['API','Web'] },
        { id: 4, q: 'What is version control and why is Git important?', tags: ['Git','Tools'] },
        { id: 5, q: 'What is the difference between SQL and NoSQL databases?', tags: ['Database'] },
      ],
      Intermediate: [
        { id: 6,  q: 'Explain the SOLID design principles with examples.', tags: ['Design Patterns','OOP'] },
        { id: 7,  q: 'What is a Binary Search Tree? Explain insertion and search operations.', tags: ['DSA','Trees'] },
        { id: 8,  q: 'What is Docker and how does containerization work?', tags: ['DevOps','Tools'] },
        { id: 9,  q: 'Explain the concept of database indexing and when to use it.', tags: ['Database','Performance'] },
        { id: 10, q: 'What is the difference between multithreading and multiprocessing?', tags: ['OS','Concurrency'] },
      ],
      Advanced: [
        { id: 11, q: 'Design a URL shortening service like bit.ly. Discuss system design choices.', tags: ['System Design'] },
        { id: 12, q: 'Explain CAP theorem and its implications for distributed systems.', tags: ['Distributed Systems'] },
        { id: 13, q: 'How would you design a rate limiting system for a high-traffic API?', tags: ['System Design','API'] },
        { id: 14, q: 'What are microservices? Compare them to monolithic architecture.', tags: ['Architecture'] },
      ],
    },
    Behavioral: {
      Beginner: [
        { id: 100, q: 'Tell me about yourself and why you chose software development.', tags: ['Introduction'] },
        { id: 101, q: 'Describe a challenging project you worked on. What did you learn?', tags: ['Experience'] },
      ],
    },
  },
  'Data Analyst': {
    Technical: {
      Intermediate: [
        { id: 200, q: 'Explain the difference between OLAP and OLTP systems.', tags: ['Database','Analytics'] },
        { id: 201, q: 'What is the difference between inner join, left join, and full outer join?', tags: ['SQL'] },
        { id: 202, q: 'Explain how you would handle missing data in a dataset.', tags: ['Data Cleaning'] },
        { id: 203, q: 'What is the Central Limit Theorem and why is it important?', tags: ['Statistics'] },
        { id: 204, q: 'Describe the steps in a typical data analysis workflow.', tags: ['Process'] },
      ],
    },
  },
};

// GET /api/questions?role=&type=&difficulty=&page=&limit=
router.get('/', authMW, (req, res) => {
  const { role = 'Software Developer', type = 'Technical', difficulty = 'Intermediate', search = '', page = 1, limit = 20 } = req.query;

  let questions = QUESTION_BANK[role]?.[type]?.[difficulty] || [];

  if (search) {
    const q = search.toLowerCase();
    questions = questions.filter(item => item.q.toLowerCase().includes(q) || item.tags?.some(t => t.toLowerCase().includes(q)));
  }

  const start = (page - 1) * limit;
  const paginated = questions.slice(start, start + Number(limit));

  res.json({ questions: paginated, total: questions.length, page: Number(page), pages: Math.ceil(questions.length / limit) });
});

// GET /api/questions/roles – list available roles
router.get('/roles', authMW, (req, res) => {
  res.json({ roles: Object.keys(QUESTION_BANK) });
});

module.exports = router;
