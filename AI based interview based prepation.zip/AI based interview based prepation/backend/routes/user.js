// ============================================================
// InterviewAI – User Profile Routes
// ============================================================

const router = require('express').Router();
const authMW = require('../middleware/auth');
const User   = require('../models/User');

// GET /api/user/profile
router.get('/profile', authMW, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/user/profile
router.put('/profile', authMW, async (req, res) => {
  const { firstName, lastName, jobRole, experience, skills, targetDate, preferredMode } = req.body;
  try {
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { firstName, lastName, jobRole, experience, skills, targetDate, preferredMode, updatedAt: new Date() },
      { new: true, runValidators: true }
    ).select('-password');
    res.json({ message: 'Profile updated.', user });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/user/stats
router.get('/stats', authMW, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('totalInterviews avgScore practiceHours streak');
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
