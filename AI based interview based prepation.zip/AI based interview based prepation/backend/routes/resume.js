// ============================================================
// InterviewAI – Resume Analysis Route
// ============================================================

const router  = require('express').Router();
const authMW  = require('../middleware/auth');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');

// Configure Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads', 'resumes');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext  = path.extname(file.originalname);
    const name = `resume_${req.user.id}_${Date.now()}${ext}`;
    cb(null, name);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowed = ['.pdf', '.doc', '.docx', '.txt'];
    if (allowed.includes(path.extname(file.originalname).toLowerCase())) {
      cb(null, true);
    } else {
      cb(new Error('Only PDF, DOC, DOCX, and TXT files are allowed.'));
    }
  }
});

// POST /api/resume/upload
router.post('/upload', authMW, upload.single('resume'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });

  let text = '';
  const ext = path.extname(req.file.originalname).toLowerCase();

  try {
    if (ext === '.pdf') {
      const pdfParse = require('pdf-parse');
      const dataBuffer = fs.readFileSync(req.file.path);
      const data = await pdfParse(dataBuffer);
      text = data.text;
    } else {
      // For .txt, .doc (plain text extraction)
      text = fs.readFileSync(req.file.path, 'utf-8');
    }

    res.json({
      message: 'Resume uploaded successfully.',
      filename: req.file.filename,
      fileUrl:  `/uploads/resumes/${req.file.filename}`,
      textPreview: text.substring(0, 500),
      fullText: text,
    });
  } catch (err) {
    console.error('[Resume Upload]', err.message);
    res.status(500).json({ error: 'Failed to process resume file.' });
  }
});

module.exports = router;
