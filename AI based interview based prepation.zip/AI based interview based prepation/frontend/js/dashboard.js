// ============================================================
// InterviewAI – Dashboard JavaScript
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // ── Auth Guard ────────────────────────────────────────────
  const token = localStorage.getItem('aiInterviewToken');
  if (!token) { window.location.href = 'login.html'; return; }

  // ── Load User ─────────────────────────────────────────────
  const userRaw = localStorage.getItem('aiInterviewUser');
  const user = userRaw ? JSON.parse(userRaw) : { name: 'User', role: 'Software Developer' };
  const firstName = (user.name || 'User').split(' ')[0];

  document.getElementById('userName').textContent = firstName;
  document.getElementById('welcomeName').textContent = firstName;
  document.getElementById('userAvatar').textContent = firstName.charAt(0).toUpperCase();

  // Greeting
  const hour = new Date().getHours();
  const greetMap = { morning: 'Good Morning ☀️', afternoon: 'Good Afternoon 🌤', evening: 'Good Evening 🌙' };
  const greet = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
  document.getElementById('greeting').textContent = greetMap[greet];

  // ── Load Stats from localStorage ─────────────────────────
  const stats = JSON.parse(localStorage.getItem('aiInterviewStats') || '{"total":0,"avgScore":0,"hours":0,"streak":0}');
  animateNumber('totalInterviews', 0, stats.total, '');
  animateNumber('avgScore', 0, stats.avgScore || 0, '%');
  document.getElementById('practiceHours').textContent = (stats.hours || 0) + 'h';
  document.getElementById('streak').textContent = stats.streak || 0;

  function animateNumber(id, from, to, suffix) {
    const el = document.getElementById(id);
    if (!el || to === 0) { el.textContent = '0' + suffix; return; }
    let start;
    const anim = (ts) => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / 1000, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(from + (to - from) * eased) + suffix;
      if (p < 1) requestAnimationFrame(anim);
    };
    requestAnimationFrame(anim);
  }

  // ── Recent Interviews ─────────────────────────────────────
  const history = JSON.parse(localStorage.getItem('aiInterviewHistory') || '[]');
  const recentList = document.getElementById('recentList');
  if (history.length > 0) {
    recentList.innerHTML = history.slice(0, 5).map(item => {
      const scoreClass = item.score >= 75 ? 'score-high' : item.score >= 50 ? 'score-medium' : 'score-low';
      return `
        <div class="recent-item">
          <div class="recent-score ${scoreClass}">${item.score}%</div>
          <div class="recent-info">
            <strong>${item.role} – ${item.type}</strong>
            <span>${formatDate(item.date)} · ${item.duration || '20 min'}</span>
          </div>
          <span class="recent-mode"><i class="fas fa-${item.mode === 'video' ? 'video' : item.mode === 'voice' ? 'microphone' : 'keyboard'}"></i></span>
        </div>`;
    }).join('');
  }

  function formatDate(dateStr) {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  // ── Performance Chart ─────────────────────────────────────
  const ctx = document.getElementById('performanceChart');
  if (ctx) {
    const weekData = {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'Score %',
        data: [62, 71, 68, 78, 82, 75, 88],
        borderColor: '#6C63FF',
        backgroundColor: 'rgba(108,99,255,0.12)',
        borderWidth: 2.5,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: '#6C63FF',
        pointRadius: 4,
        pointHoverRadius: 6,
      }]
    };
    const monthData = {
      labels: ['Wk 1', 'Wk 2', 'Wk 3', 'Wk 4'],
      datasets: [{
        label: 'Score %',
        data: [60, 70, 76, 85],
        borderColor: '#6C63FF',
        backgroundColor: 'rgba(108,99,255,0.12)',
        borderWidth: 2.5, fill: true, tension: 0.4,
        pointBackgroundColor: '#6C63FF', pointRadius: 4, pointHoverRadius: 6,
      }]
    };

    const chartOptions = {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#6B7295', font: { size: 11 } } },
        y: { min: 0, max: 100, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#6B7295', font: { size: 11 }, callback: v => v + '%' } }
      }
    };

    let perfChart = new Chart(ctx, { type: 'line', data: weekData, options: chartOptions });

    window.switchChart = (period, btn) => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      perfChart.data = period === 'week' ? weekData : monthData;
      perfChart.update();
    };
  }

  // ── Skill Radar Chart ─────────────────────────────────────
  const skillCtx = document.getElementById('skillChart');
  if (skillCtx) {
    new Chart(skillCtx, {
      type: 'radar',
      data: {
        labels: ['Technical', 'Communication', 'Problem Solving', 'Confidence', 'Clarity', 'Speed'],
        datasets: [{
          label: 'Your Skills',
          data: [78, 70, 82, 65, 74, 68],
          borderColor: '#6C63FF',
          backgroundColor: 'rgba(108,99,255,0.18)',
          borderWidth: 2,
          pointBackgroundColor: '#6C63FF',
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          r: {
            min: 0, max: 100,
            ticks: { stepSize: 20, color: '#6B7295', font: { size: 10 } },
            grid: { color: 'rgba(255,255,255,0.08)' },
            pointLabels: { color: '#A0A8C8', font: { size: 11 } },
          }
        }
      }
    });
  }

  // ── Sidebar Collapse ──────────────────────────────────────
  const sidebarToggle = document.getElementById('sidebarToggle');
  const appLayout = document.querySelector('.app-layout');
  const sidebar = document.getElementById('sidebar');

  sidebarToggle?.addEventListener('click', () => {
    appLayout.classList.toggle('sidebar-collapsed');
    const icon = sidebarToggle.querySelector('i');
    icon.className = appLayout.classList.contains('sidebar-collapsed') ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
  });

  // Mobile Sidebar
  const mobileSidebarBtn = document.getElementById('mobileSidebarBtn');
  mobileSidebarBtn?.addEventListener('click', () => {
    sidebar.classList.toggle('mobile-open');
  });

  console.log('%c InterviewAI Dashboard ✅', 'color:#6C63FF; font-size:14px; font-weight:bold;');
});

function logout() {
  if (confirm('Are you sure you want to logout?')) {
    localStorage.removeItem('aiInterviewToken');
    localStorage.removeItem('aiInterviewUser');
    window.location.href = 'login.html';
  }
}
