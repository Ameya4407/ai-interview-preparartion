-- ============================================================
-- InterviewAI – MySQL Database Schema
-- ============================================================
-- Run this file: mysql -u root -p < database/schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS interviewai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE interviewai;

-- ── Users Table ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100) NOT NULL,
  email           VARCHAR(255) NOT NULL UNIQUE,
  password_hash   VARCHAR(255) NOT NULL,
  avatar_url      VARCHAR(500),
  job_role        VARCHAR(100) DEFAULT 'Software Developer',
  experience_level ENUM('Fresher','Beginner','Intermediate','Advanced') DEFAULT 'Beginner',
  skills          JSON,
  target_date     DATE,
  resume_url      VARCHAR(500),
  ats_score       TINYINT UNSIGNED,
  total_interviews INT UNSIGNED DEFAULT 0,
  avg_score       TINYINT UNSIGNED DEFAULT 0,
  practice_hours  DECIMAL(6,2) DEFAULT 0.00,
  streak          INT UNSIGNED DEFAULT 0,
  preferred_mode  ENUM('text','voice','video') DEFAULT 'voice',
  notifications   BOOLEAN DEFAULT TRUE,
  is_active       BOOLEAN DEFAULT TRUE,
  is_verified     BOOLEAN DEFAULT FALSE,
  last_active_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email)
) ENGINE=InnoDB;

-- ── Interview Sessions Table ──────────────────────────────────
CREATE TABLE IF NOT EXISTS interview_sessions (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id          BIGINT UNSIGNED NOT NULL,
  job_role         VARCHAR(100) NOT NULL,
  difficulty       ENUM('Beginner','Intermediate','Advanced') DEFAULT 'Intermediate',
  interview_type   ENUM('Technical','HR','Behavioral','Mixed') DEFAULT 'Technical',
  mode             ENUM('text','voice','video') DEFAULT 'text',
  total_questions  INT UNSIGNED DEFAULT 10,
  answered_count   INT UNSIGNED DEFAULT 0,
  avg_score        TINYINT UNSIGNED DEFAULT 0,
  tech_score       TINYINT UNSIGNED DEFAULT 0,
  communication_score TINYINT UNSIGNED DEFAULT 0,
  confidence_score TINYINT UNSIGNED DEFAULT 0,
  clarity_score    TINYINT UNSIGNED DEFAULT 0,
  problem_solving_score TINYINT UNSIGNED DEFAULT 0,
  ai_summary       TEXT,
  key_strengths    JSON,
  areas_to_improve JSON,
  status           ENUM('active','completed','abandoned') DEFAULT 'active',
  started_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ended_at         TIMESTAMP,
  duration_minutes INT UNSIGNED,
  report_url       VARCHAR(500),
  is_bookmarked    BOOLEAN DEFAULT FALSE,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- ── Questions & Answers Table ─────────────────────────────────
CREATE TABLE IF NOT EXISTS session_answers (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id       BIGINT UNSIGNED NOT NULL,
  question_index   INT UNSIGNED NOT NULL,
  question_text    TEXT NOT NULL,
  question_category VARCHAR(100),
  question_hint    TEXT,
  answer_text      TEXT,
  score            TINYINT UNSIGNED DEFAULT 0,
  feedback         TEXT,
  strengths        TEXT,
  improvements     TEXT,
  follow_up_q      TEXT,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (session_id) REFERENCES interview_sessions(id) ON DELETE CASCADE,
  INDEX idx_session_id (session_id)
) ENGINE=InnoDB;

-- ── Transcript Table ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS session_transcripts (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id  BIGINT UNSIGNED NOT NULL,
  speaker     ENUM('AI','User') NOT NULL,
  message     TEXT NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (session_id) REFERENCES interview_sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Question Bank Table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS question_bank (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_role     VARCHAR(100) NOT NULL,
  category     ENUM('Technical','HR','Behavioral','Mixed') NOT NULL,
  difficulty   ENUM('Beginner','Intermediate','Advanced') NOT NULL,
  question     TEXT NOT NULL,
  sample_answer TEXT,
  tags         JSON,
  times_asked  INT UNSIGNED DEFAULT 0,
  avg_score    TINYINT UNSIGNED DEFAULT 0,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_role_cat_diff (job_role, category, difficulty)
) ENGINE=InnoDB;

-- ── Bookmarks Table ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bookmarks (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      BIGINT UNSIGNED NOT NULL,
  question_id  BIGINT UNSIGNED NOT NULL,
  note         TEXT,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_bookmark (user_id, question_id),
  FOREIGN KEY (user_id)     REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES question_bank(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Study Planner Table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS study_plans (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      BIGINT UNSIGNED NOT NULL,
  plan_data    JSON NOT NULL,
  target_date  DATE,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Study Tasks Table ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS study_tasks (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      BIGINT UNSIGNED NOT NULL,
  plan_id      BIGINT UNSIGNED,
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  scheduled_at DATETIME,
  duration_min INT UNSIGNED DEFAULT 30,
  is_completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMP,
  priority     ENUM('low','medium','high') DEFAULT 'medium',
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (plan_id) REFERENCES study_plans(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── Seed Sample Questions ─────────────────────────────────────
INSERT INTO question_bank (job_role, category, difficulty, question, sample_answer, tags) VALUES
('Software Developer','Technical','Beginner','What is Object-Oriented Programming and what are its four pillars?','OOP is a programming paradigm based on objects. The four pillars are: 1) Encapsulation 2) Inheritance 3) Polymorphism 4) Abstraction.','["OOP","Basics","Programming"]'),
('Software Developer','Technical','Beginner','What is the difference between an array and a linked list?','Arrays store data in contiguous memory with O(1) access but O(n) insertion. Linked lists use nodes with pointers, O(n) access but O(1) insertion at head.','["DSA","Arrays","LinkedList"]'),
('Software Developer','Technical','Intermediate','Explain the SOLID design principles with examples.','SOLID: Single Responsibility, Open/Closed, Liskov Substitution, Interface Segregation, Dependency Inversion. Each principle promotes maintainable, extensible code.','["DesignPatterns","SOLID","OOP"]'),
('Software Developer','Technical','Advanced','Design a URL shortening service. Discuss architecture decisions.','Use a hash function to generate short codes, store in distributed DB (Cassandra), use CDN for redirects, rate limiting, analytics pipeline with Kafka.','["SystemDesign","Architecture","Scalability"]'),
('Software Developer','Behavioral','Beginner','Tell me about yourself and why you chose software development.','Structure: Education background, key projects, technical skills, passion for problem-solving, career goals.','["Introduction","Background"]'),
('Software Developer','HR','Beginner','Where do you see yourself in 5 years?','Focus on growth within the company, technical leadership, and contributing to meaningful projects while aligning with company goals.','["CareerGoals","HR"]'),
('Data Analyst','Technical','Intermediate','Explain the difference between INNER JOIN, LEFT JOIN, and FULL OUTER JOIN.','INNER JOIN returns matching rows only. LEFT JOIN returns all left rows + matches. FULL OUTER JOIN returns all rows from both tables with NULLs for non-matches.','["SQL","Database","Joins"]'),
('Frontend Developer','Technical','Beginner','What is the difference between CSS Flexbox and Grid?','Flexbox is 1D (row or column), ideal for component layouts. Grid is 2D (rows and columns), ideal for page-level layouts.','["CSS","Layout","Frontend"]'),
('Python Developer','Technical','Intermediate','Explain Python decorators and how they work.','Decorators are functions that wrap other functions to extend behavior without modifying the original. They use @decorator syntax and closures.','["Python","Decorators","Advanced"]');

-- ── Views ─────────────────────────────────────────────────────
CREATE OR REPLACE VIEW user_performance_summary AS
SELECT 
  u.id,
  u.first_name,
  u.last_name,
  u.email,
  u.job_role,
  u.total_interviews,
  u.avg_score,
  u.practice_hours,
  u.streak,
  COUNT(DISTINCT s.id) AS completed_sessions,
  AVG(s.avg_score) AS actual_avg_score,
  SUM(s.duration_minutes) AS total_minutes
FROM users u
LEFT JOIN interview_sessions s ON s.user_id = u.id AND s.status = 'completed'
GROUP BY u.id;
