// ============================================================
// InterviewAI – Enterprise Landing Page JavaScript
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // ── Navbar Scroll Effect ─────────────────────────────────
  const navbar = document.getElementById('navbar');
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 30);
  });

  // ── Mobile Menu Toggle ───────────────────────────────────
  const navToggle = document.getElementById('navToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  if (navToggle && mobileMenu) {
    navToggle.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
      const icon = navToggle.querySelector('i');
      icon.className = mobileMenu.classList.contains('open') ? 'fas fa-times' : 'fas fa-bars';
    });
    mobileMenu.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        mobileMenu.classList.remove('open');
        navToggle.querySelector('i').className = 'fas fa-bars';
      });
    });
  }

  // ── Smooth Scroll for Anchor Links ───────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', e => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // ── Intersection Observer – Subtle Fade-in on Scroll ────
  const observerOpts = { threshold: 0.1, rootMargin: '0px 0px -40px 0px' };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, observerOpts);

  document.querySelectorAll('.feature-card, .mode-card, .step-card, .testimonial-card').forEach((el, i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = `opacity 0.45s ease ${i * 0.05}s, transform 0.45s ease ${i * 0.05}s`;
    observer.observe(el);
  });

  // ── Stats Counter Animation ───────────────────────────────
  const statNums = document.querySelectorAll('.stat-num');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        counterObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  statNums.forEach(el => counterObserver.observe(el));

  function animateCounter(el) {
    const raw    = el.textContent.replace(/[^0-9]/g, '');
    const end    = parseInt(raw, 10);
    const suffix = el.textContent.replace(/[0-9]/g, '');
    if (!end) return;
    let start = 0;
    const duration = 1600;
    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.floor(eased * end) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ── Hero Meeting Mockup Live Caption Rotation ────────────
  const captionEl = document.querySelector('.mockup-caption-box span:last-child');
  if (captionEl) {
    const questions = [
      '"Could you walk me through how you optimize database indexing when table rows exceed 10 million records?"',
      '"Tell me about a time you had a technical disagreement with an engineer. How did you resolve it?"',
      '"Explain the difference between synchronous execution and asynchronous event loops in Node.js."',
      '"How would you design a distributed rate-limiter with high availability and low latency?"'
    ];
    let qi = 0;
    setInterval(() => {
      captionEl.style.opacity = '0';
      captionEl.style.transition = 'opacity 0.3s ease';
      setTimeout(() => {
        qi = (qi + 1) % questions.length;
        captionEl.textContent = questions[qi];
        captionEl.style.opacity = '1';
      }, 300);
    }, 4500);
  }

  console.log('%c InterviewAI Enterprise UI Loaded ✅', 'color:#4F46E5; font-size:14px; font-weight:bold;');
});
