// ============================================================
// InterviewAI – Interview Session Routes
// ============================================================

const router  = require('express').Router();
const authMW  = require('../middleware/auth');
const InterviewSession = require('../models/InterviewSession');
const User    = require('../models/User');

// ── POST /api/interview/start ─────────────────────────────────
router.post('/start', authMW, async (req, res) => {
  const { role, difficulty, type, mode, totalQuestions } = req.body;

  try {
    const session = await InterviewSession.create({
      userId:    req.user.id,
      role, difficulty, type, mode,
      totalQuestions: totalQuestions || 10,
      startedAt: new Date(),
      status:    'active',
    });
    res.status(201).json({ sessionId: session._id, message: 'Interview session started.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/interview/:id/answer ─────────────────────────────
router.put('/:id/answer', authMW, async (req, res) => {
  const { questionText, answerText, score, feedback, strengths, improvements, questionIndex } = req.body;

  try {
    const session = await InterviewSession.findOne({ _id: req.params.id, userId: req.user.id });
    if (!session) return res.status(404).json({ error: 'Session not found.' });

    session.answers.push({ questionIndex, questionText, answerText, score, feedback, strengths, improvements });
    session.questions.push({ text: questionText });
    await session.save();

    res.json({ message: 'Answer saved.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/interview/:id/complete ───────────────────────────
router.put('/:id/complete', authMW, async (req, res) => {
  const { transcript, scores, aiSummary, keyStrengths, areasToImprove } = req.body;

  try {
    const session = await InterviewSession.findOne({ _id: req.params.id, userId: req.user.id });
    if (!session) return res.status(404).json({ error: 'Session not found.' });

    session.status     = 'completed';
    session.endedAt    = new Date();
    session.duration   = Math.floor((new Date() - session.startedAt) / 60000);
    session.transcript = transcript || [];
    session.scores     = scores || {};
    session.aiSummary  = aiSummary;
    session.keyStrengths    = keyStrengths || [];
    session.areasToImprove  = areasToImprove || [];
    await session.save();

    // Update user stats
    const user = await User.findById(req.user.id);
    if (user) {
      user.totalInterviews += 1;
      user.practiceHours = Math.round((user.practiceHours + (session.duration / 60)) * 100) / 100;
      const totalSessions = user.totalInterviews;
      user.avgScore = Math.round(((user.avgScore * (totalSessions - 1)) + session.avgScore) / totalSessions);
      await user.save();
    }

    res.json({ message: 'Interview completed.', session });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/interview/history ────────────────────────────────
router.get('/history', authMW, async (req, res) => {
  try {
    const { page = 1, limit = 10, role, type } = req.query;
    const filter = { userId: req.user.id, status: 'completed' };
    if (role) filter.role = role;
    if (type) filter.type = type;

    const sessions = await InterviewSession.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .select('-answers -transcript');

    const total = await InterviewSession.countDocuments(filter);
    res.json({ sessions, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/interview/:id ────────────────────────────────────
router.get('/:id', authMW, async (req, res) => {
  try {
    const session = await InterviewSession.findOne({ _id: req.params.id, userId: req.user.id });
    if (!session) return res.status(404).json({ error: 'Session not found.' });
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PATCH /api/interview/:id/bookmark ─────────────────────────
router.patch('/:id/bookmark', authMW, async (req, res) => {
  try {
    const session = await InterviewSession.findOne({ _id: req.params.id, userId: req.user.id });
    if (!session) return res.status(404).json({ error: 'Session not found.' });
    session.isBookmarked = !session.isBookmarked;
    await session.save();
    res.json({ bookmarked: session.isBookmarked });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Stubs for other routes
router.use('/user', require('./user'));
router.use('/questions', require('./questions'));
router.use('/analytics', require('./analytics'));
router.use('/resume', require('./resume'));
router.use('/report', require('./report'));

module.exports = router;
