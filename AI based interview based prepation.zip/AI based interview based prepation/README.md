# InterviewAI – AI-Powered Interview Preparation Platform
> **BCA Major Project** | Built with HTML, CSS, JavaScript, Node.js, Express.js, MongoDB/MySQL & Google Gemini API

---

## 📋 Project Overview

**InterviewAI** is a comprehensive AI-powered interview preparation platform that provides students and job seekers with a realistic interview experience using a virtual AI interviewer. Powered by **Google Gemini 2.0 Flash**, it generates dynamic questions, evaluates answers intelligently, and provides detailed personalized feedback.

---

## 🚀 Features

| Feature | Status |
|---|---|
| AI Virtual Interviewer (Animated Avatar) | ✅ |
| Text, Voice & Video Interview Modes | ✅ |
| Gemini AI Question Generation | ✅ |
| Gemini AI Answer Evaluation | ✅ |
| Real-time Speech-to-Text | ✅ |
| Text-to-Speech (AI reads questions) | ✅ |
| Eye-tracking & Mouth Animation | ✅ |
| User Registration & Login (JWT) | ✅ |
| Personalized Dashboard | ✅ |
| Performance Analytics (Chart.js) | ✅ |
| AI Resume Analyzer + ATS Score | ✅ |
| Interview History & Bookmarks | ✅ |
| Study Planner | ✅ |
| Question Bank (5000+ questions) | ✅ |
| Downloadable Interview Reports | ✅ |
| Interview Timer | ✅ |
| Live Transcript | ✅ |
| Skill Assessment (Radar Chart) | ✅ |
| Node.js/Express REST API Backend | ✅ |
| MongoDB Database Schema | ✅ |
| MySQL Database Schema | ✅ |
| Multi-step Interview Setup Wizard | ✅ |

---

## 🛠 Technology Stack

### Frontend
- **HTML5** – Semantic markup
- **CSS3** – Custom design system (dark theme, glassmorphism)
- **JavaScript (ES6+)** – Dynamic UI, animations, API calls
- **Chart.js** – Performance charts and skill radar
- **Web Speech API** – Speech-to-text & text-to-speech
- **MediaDevices API** – Camera & microphone access

### Backend
- **Node.js** – JavaScript runtime
- **Express.js** – REST API framework
- **JWT (jsonwebtoken)** – Authentication
- **bcryptjs** – Password hashing
- **Multer** – File upload (resume)
- **PDFKit** – PDF report generation
- **pdf-parse** – PDF text extraction
- **Helmet** – Security headers
- **express-rate-limit** – Rate limiting

### AI / APIs
- **Google Gemini 2.0 Flash API** – Question generation, answer evaluation, resume analysis, study plans

### Database
- **MongoDB** (Primary) – via Mongoose ODM
- **MySQL** (Alternative) – Full schema with views and seed data

---

## 📁 Project Structure

```
AI based interview based prepation/
├── frontend/
│   ├── index.html              ← Landing page
│   ├── css/
│   │   ├── styles.css          ← Global design system
│   │   ├── landing.css         ← Landing page styles
│   │   ├── auth.css            ← Login/Register styles
│   │   ├── dashboard.css       ← Dashboard styles
│   │   ├── setup.css           ← Interview setup styles
│   │   └── interview.css       ← Interview room styles
│   ├── js/
│   │   ├── landing.js          ← Landing page scripts
│   │   ├── auth.js             ← Authentication scripts
│   │   ├── dashboard.js        ← Dashboard + Chart.js
│   │   ├── setup.js            ← Interview configuration
│   │   └── interview.js        ← AI interview engine (core)
│   └── pages/
│       ├── login.html          ← Login page
│       ├── register.html       ← Registration page
│       ├── dashboard.html      ← User dashboard
│       ├── interview-setup.html← 4-step setup wizard
│       ├── interview.html      ← Live interview room
│       ├── report.html         ← Performance report
│       ├── resume-analyzer.html← AI resume analysis
│       ├── history.html        ← Interview history
│       ├── analytics.html      ← Performance analytics
│       ├── question-bank.html  ← Question bank
│       ├── coding.html         ← Coding practice arena
│       ├── study-planner.html  ← AI study planner
│       ├── bookmarks.html      ← Saved questions
│       └── profile.html        ← User profile
│
├── backend/
│   ├── server.js               ← Express server entry point
│   ├── package.json            ← Node.js dependencies
│   ├── .env.example            ← Environment variables template
│   ├── config/
│   │   └── database.js         ← MongoDB connection
│   ├── models/
│   │   ├── User.js             ← User model (Mongoose)
│   │   └── InterviewSession.js ← Session model (Mongoose)
│   ├── middleware/
│   │   └── auth.js             ← JWT authentication middleware
│   └── routes/
│       ├── auth.js             ← Register/Login/Me endpoints
│       ├── user.js             ← Profile & stats endpoints
│       ├── interview.js        ← Session CRUD endpoints
│       ├── gemini.js           ← Gemini AI integration endpoints
│       ├── resume.js           ← Resume upload & parse
│       ├── questions.js        ← Question bank API
│       ├── analytics.js        ← Performance analytics
│       └── report.js           ← PDF report generation
│
└── database/
    └── schema.sql              ← MySQL schema + seed data
```

---

## ⚡ Quick Start Guide (Zero Setup & Free)

### Option 1: 100% Free Instant Mode (No API Key Required!)
The platform comes with **Free Auto-AI Active by default**:
1. Open [`frontend/index.html`](file:///c:/Users/anubh/OneDrive/Documents/Desktop/AI%20based%20interview%20based%20prepation/frontend/index.html) in your browser (Google Chrome or Microsoft Edge).
2. Click **Get Started Free** → Register (or Login with Demo).
3. Click **Start Interview** → choose your Job Role, Difficulty, and Mode (Text, Voice, or Video).
4. **Start practicing immediately!** The platform connects to free open AI inference with automated semantic fallback so questions, scoring, hints, and feedback work without requiring any payment or signup!

---

### Option 2: Connect Optional Free Google Gemini Key (15 RPM Free Tier)
If you'd like to use Google's Gemini 2.0 Flash API:
1. Get your free key at: [Google AI Studio](https://aistudio.google.com/app/apikey) (Free tier, no credit card required)
2. Go to **Profile** or the **Resume Analyzer** page inside the app.
3. Paste your key and click **Save**. The app will automatically route requests through your Gemini account.

### Step 3: Setup Backend (Optional for Full Features)
```bash
# Navigate to backend folder
cd backend

# Install dependencies
npm install

# Copy environment file
copy .env.example .env

# Edit .env and add your keys:
#   GEMINI_API_KEY=your_key_here
#   MONGODB_URI=mongodb://localhost:27017/interviewai
#   JWT_SECRET=your_strong_secret

# Start development server
npm run dev

# Server runs at: http://localhost:5000
```

### Step 4: Setup Database
**MongoDB (Recommended):**
```bash
# Install MongoDB Community Edition
# Start mongod service
# The app auto-creates collections
```

**MySQL (Alternative):**
```bash
mysql -u root -p < database/schema.sql
```

---

## 🎯 Interview Modes

### 📝 Text Mode
- Type answers in a text area
- No camera or mic needed
- Grammar and structure feedback
- Unlimited time

### 🎤 Voice Mode (Recommended)
- Click to speak, speech-to-text converts your answer
- Real-time audio visualizer
- Fluency scoring
- AI reads questions aloud

### 📹 Video Mode
- Full camera + microphone access
- Face-to-face simulation
- Body language tips
- Most realistic experience

---

## 🤖 AI Features (Gemini-Powered)

### Dynamic Question Generation
```
POST /api/gemini/generate-question
{
  "role": "Software Developer",
  "difficulty": "Intermediate",
  "type": "Technical",
  "questionNumber": 1,
  "totalQuestions": 10
}
```

### Intelligent Answer Evaluation
```
POST /api/gemini/evaluate-answer
{
  "question": "Explain SOLID principles",
  "answer": "SOLID stands for...",
  "role": "Software Developer"
}
```

### Resume Analysis + ATS Score
```
POST /api/gemini/analyze-resume
{
  "resumeText": "...",
  "targetRole": "Software Developer"
}
```

---

## 🔐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login user |
| GET  | `/api/auth/me` | Get current user |
| GET  | `/api/user/profile` | Get user profile |
| PUT  | `/api/user/profile` | Update profile |
| POST | `/api/interview/start` | Start new session |
| PUT  | `/api/interview/:id/answer` | Save answer |
| PUT  | `/api/interview/:id/complete` | Complete session |
| GET  | `/api/interview/history` | Get history |
| POST | `/api/gemini/generate-question` | AI question generation |
| POST | `/api/gemini/evaluate-answer` | AI answer evaluation |
| POST | `/api/gemini/analyze-resume` | AI resume analysis |
| POST | `/api/resume/upload` | Upload resume file |
| GET  | `/api/analytics/overview` | Performance analytics |
| GET  | `/api/questions` | Question bank |
| GET  | `/api/report/:id/pdf` | Download PDF report |

---

## 📊 Database Schemas

### MongoDB Collections
- `users` – User accounts and stats
- `interviewsessions` – Interview session records with Q&A

### MySQL Tables
- `users` – User accounts
- `interview_sessions` – Session records
- `session_answers` – Individual Q&A data
- `session_transcripts` – Full conversation transcripts
- `question_bank` – Curated question library
- `bookmarks` – Saved questions
- `study_plans` – AI-generated study plans
- `study_tasks` – Individual daily tasks

---

## 🎨 Design System

| Token | Value |
|-------|-------|
| Primary | `#6C63FF` (Purple) |
| Accent | `#43E97B` (Green) |
| Background | `#0A0B1A` (Dark Navy) |
| Card BG | `#12142A` |
| Font | Inter + Poppins |
| Border Radius | 8px – 28px |
| Shadows | Multi-layer depth |

---

## 📱 Responsive Design

The platform is fully responsive:
- **Desktop** (1200px+) – Full sidebar + multi-column layout
- **Tablet** (768px–1200px) – Collapsible sidebar
- **Mobile** (<768px) – Drawer navigation, single column

---

## 🔧 Development Roadmap

### Phase 1 ✅ (Current)
- Landing page, Auth, Dashboard
- Interview room (Text/Voice/Video)
- Gemini AI integration
- Resume analyzer
- Performance reports

### Phase 2 (Planned)
- Real 3D avatar with lip sync (ReadyPlayerMe + Three.js)
- Coding arena with Judge0 API
- Advanced analytics dashboard
- Push notifications
- Mobile app (React Native)

### Phase 3 (Future)
- Group interview simulation
- Company-specific preparation packs
- Interview scheduling with calendar integration
- AI coaching chatbot

---

## 👨‍💻 Project Information

| Field | Detail |
|-------|--------|
| Project Type | BCA Major Project |
| Year | 2026 |
| Technology | Full-Stack Web + AI |
| AI Provider | Google Gemini 2.0 Flash |
| License | Academic / Educational |

---

## 🙏 Acknowledgements

- **Google Gemini API** for powering the AI interviewer
- **Chart.js** for beautiful performance visualizations
- **Font Awesome** for icons
- **Web Speech API** for speech recognition
- All open-source contributors

---

> *InterviewAI – Helping students become job-ready through realistic AI-powered interview practice.*
