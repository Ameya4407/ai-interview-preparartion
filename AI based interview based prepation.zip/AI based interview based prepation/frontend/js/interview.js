// ============================================================
// InterviewAI – Interview Room JavaScript (Gemini API Powered)
// ============================================================

// ── Configuration ─────────────────────────────────────────────
const config  = JSON.parse(sessionStorage.getItem('interviewConfig') || '{}');
const user    = JSON.parse(localStorage.getItem('aiInterviewUser')  || '{}');
const API_KEY = sessionStorage.getItem('geminiApiKey') || 'YOUR_GEMINI_API_KEY'; // set by user

const interview = {
  questions:   [],
  answers:     [],
  currentQ:    0,
  totalQ:      parseInt(config.qCount) || 10,
  startTime:   null,
  qTimer:      null,
  transcript:  [],
  isRecording: false,
  recognition: null,
  mediaStream: null,
  audioContext: null,
  analyser:    null,
};

// ── DOM References ─────────────────────────────────────────────
const $  = id => document.getElementById(id);
const questionText    = $('questionText');
const feedbackCard    = $('feedbackCard');
const feedbackContent = $('feedbackContent');
const feedbackScore   = $('feedbackScore');
const miniTranscript  = $('miniTranscript');
const transcriptFull  = $('transcriptFull');
const avatarMouth     = $('avatarMouth');
const speakingInd     = $('speakingIndicator');
const avatarGlow      = $('avatarGlow');
const statusText      = $('statusText');
const statusDot       = document.querySelector('.status-dot');

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  if (!localStorage.getItem('aiInterviewToken')) {
    window.location.href = 'login.html'; return;
  }

  // Set meta chips
  $('metaRole').textContent = config.role || 'Software Developer';
  $('metaType').textContent = config.type || 'Technical';
  $('metaDiff').textContent = config.difficulty || 'Intermediate';
  $('qTotal').textContent   = interview.totalQ;

  // Show correct answer UI
  const mode = config.mode || 'text';
  if (mode === 'voice') {
    $('textAnswerWrap').style.display = 'none';
    $('voiceAnswerWrap').style.display = 'block';
    setupSpeechRecognition();
  } else if (mode === 'video') {
    $('textAnswerWrap').style.display = 'none';
    $('videoAnswerWrap').style.display = 'block';
    setupVideoMode();
    setupSpeechRecognition('video');
  }

  // Start session
  interview.startTime = Date.now();
  startSessionTimer();

  // Load first question
  await loadQuestion(0);
});

// ── Session Timer ─────────────────────────────────────────────
function startSessionTimer() {
  setInterval(() => {
    const elapsed = Math.floor((Date.now() - interview.startTime) / 1000);
    const m = String(Math.floor(elapsed / 60)).padStart(2, '0');
    const s = String(elapsed % 60).padStart(2, '0');
    $('timerText').textContent = `${m}:${s}`;
  }, 1000);
}

// ── Load Question via Gemini API ──────────────────────────────
async function loadQuestion(index) {
  if (index >= interview.totalQ) { finalizeInterview(); return; }

  interview.currentQ = index;
  $('qCurrent').textContent = index + 1;
  $('qNum').textContent     = index + 1;
  $('progressFill').style.width = `${((index + 1) / interview.totalQ) * 100}%`;

  // Hide feedback, show answer area
  feedbackCard.style.display = 'none';
  $('answerArea').style.display = 'block';

  // Set status
  setAvatarStatus('speaking', 'AI is thinking...');
  questionText.innerHTML = `
    <div class="question-loading">
      <div class="dot-pulse">
        <div class="dp-dot"></div><div class="dp-dot"></div><div class="dp-dot"></div>
      </div>
      <span>Generating question...</span>
    </div>`;

  let question;
  if (interview.questions[index]) {
    question = interview.questions[index];
  } else {
    question = await generateQuestion(index);
    interview.questions[index] = question;
  }

  // Display question
  questionText.textContent = question.text;
  $('qCategory').textContent  = question.category || config.type;
  $('qDifficulty').textContent = config.difficulty;
  $('questionHint').style.display = 'none';

  // AI "speaks" the question
  speakText(question.text);

  // Add to transcript
  addTranscript('AI', question.text);

  // Reset answer fields
  if ($('textAnswer')) $('textAnswer').value = '';
  if ($('voiceTranscript')) $('voiceTranscript').innerHTML = '<p>Your speech will appear here as you speak...</p>';
  if ($('videoTranscript')) $('videoTranscript').innerHTML = '<p>Your speech will appear here as you speak...</p>';
  if ($('wordCount')) $('wordCount').textContent = '0 words';
  if ($('submitVoiceBtn')) $('submitVoiceBtn').disabled = true;

  setAvatarStatus('listening', 'Listening for your answer...');

  // Start per-question timer
  startQuestionTimer(parseInt(config.timeLimit) || 0);
}

// ── Generate Question with Gemini ─────────────────────────────
async function generateQuestion(index) {
  const previousQs = interview.questions
    .filter(Boolean)
    .map((q, i) => `Q${i+1}: ${q.text}`)
    .join('\n');

  const context = interview.answers.length > 0
    ? `\nThe candidate's last answer was: "${interview.answers[interview.answers.length - 1]?.text}"\n`
    : '';

  const prompt = `You are an expert ${config.type} interviewer conducting a ${config.difficulty} level interview for a ${config.role} position.
${previousQs ? `Previous questions asked:\n${previousQs}\n` : ''}${context}
Generate interview question #${index + 1} of ${interview.totalQ}.
- Ask a NEW, different question from the previous ones.
- Match the ${config.difficulty} difficulty level.
- If this is question ${Math.floor(interview.totalQ / 2) + 1} or later and the candidate answered the previous question, ask a relevant follow-up.
- For ${config.type} interviews: ${getTypeGuidance()}

Respond with ONLY a JSON object in this exact format:
{"text": "The question text here", "category": "Technical/HR/Behavioral", "hint": "A subtle hint for the candidate"}`;

  try {
    const response = await callGeminiAPI(prompt);
    const json = JSON.parse(response);
    return json;
  } catch {
    // Fallback questions
    return getFallbackQuestion(index, config.role, config.type, config.difficulty);
  }
}

function getTypeGuidance() {
  const guides = {
    Technical:  'Focus on coding, algorithms, data structures, system design, and technical concepts.',
    HR:         'Focus on background, career goals, salary expectations, and company culture fit.',
    Behavioral: 'Use STAR format questions about past experiences, teamwork, and leadership.',
    Mixed:      'Alternate between technical skills and behavioral/HR questions.',
  };
  return guides[config.type] || guides.Technical;
}

// ── Call AI Engine (Multi-Tier: Free Public AI + Gemini + Semantic Fallback) ──
async function callAIEngine(prompt, systemPrompt = '') {
  const savedKey = sessionStorage.getItem('geminiApiKey') || localStorage.getItem('geminiApiKey');
  const aiProvider = localStorage.getItem('aiProvider') || 'free';

  // 1. If user explicitly provided a Gemini API Key, try Google Gemini first
  if (savedKey && savedKey !== 'YOUR_GEMINI_API_KEY' && aiProvider !== 'free_offline') {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${savedKey}`;
      const body = {
        contents: [{ parts: [{ text: (systemPrompt ? systemPrompt + "\n\n" : "") + prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 600 }
      };
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (res.ok) {
        const data = await res.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text) return text;
      }
    } catch (e) {
      console.warn('Gemini API call failed, falling back to Free Public AI:', e.message);
    }
  }

  // 2. Free Public Cloud LLM (Pollinations AI - 100% Free, No Key Required, Zero Signup)
  if (aiProvider !== 'free_offline') {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 9000);
      const res = await fetch('https://text.pollinations.ai/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: systemPrompt || 'You are an expert AI interviewer. Output strictly valid JSON without markdown wrapping.' },
            { role: 'user', content: prompt }
          ],
          model: 'openai',
          jsonMode: true
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (res.ok) {
        const raw = await res.text();
        if (raw && raw.trim().length > 5) return raw;
      }
    } catch (e) {
      console.warn('Pollinations AI request failed or timed out, using Local Semantic Engine:', e.message);
    }
  }

  // 3. Fallback: Throw error to trigger smart semantic evaluator
  throw new Error('Using built-in intelligent evaluation engine');
}

// ── Smart Semantic Evaluator (Instant, Offline, Zero-Key, Contextual) ──
function semanticEvaluate(question, answer, role, diff, type) {
  const ans = (answer || '').trim();
  const wordCount = ans.split(/\s+/).filter(Boolean).length;
  const lowerAns = ans.toLowerCase();

  // Role keyword banks
  const roleKeywords = {
    'Software Developer': ['algorithm', 'complexity', 'o(n)', 'memory', 'scale', 'architecture', 'design', 'test', 'clean code', 'database', 'debug', 'git', 'api', 'oop', 'function', 'class', 'interface', 'async', 'performance'],
    'Frontend Developer': ['react', 'dom', 'css', 'javascript', 'state', 'props', 'component', 'responsive', 'flexbox', 'grid', 'html', 'lifecycle', 'hook', 'bundle', 'render', 'browser', 'event'],
    'Backend Developer': ['api', 'rest', 'database', 'sql', 'nosql', 'server', 'microservice', 'auth', 'jwt', 'docker', 'endpoint', 'cache', 'redis', 'security', 'schema', 'throughput', 'latency'],
    'Python Developer': ['list comprehension', 'generator', 'decorator', 'gil', 'dictionary', 'pandas', 'numpy', 'oop', 'pip', 'tuple', 'lambda', 'module', 'memory', 'asyncio', 'type hinting'],
    'Data Analyst': ['sql', 'query', 'aggregate', 'pandas', 'visualization', 'tableau', 'power bi', 'outlier', 'distribution', 'median', 'mean', 'excel', 'join', 'group by', 'metrics', 'cleaning']
  };

  const keywords = roleKeywords[role] || roleKeywords['Software Developer'];
  const matchedKeywords = keywords.filter(kw => lowerAns.includes(kw));

  // Behavioral indicators (STAR: Situation, Task, Action, Result)
  const starIndicators = ['when', 'project', 'team', 'challenge', 'task', 'decided', 'implemented', 'improved', 'learned', 'result', 'finally', 'impact', 'delivered'];
  const matchedStar = starIndicators.filter(st => lowerAns.includes(st));

  // Length score (up to 35 pts)
  let lengthScore = 0;
  if (wordCount >= 80) lengthScore = 35;
  else if (wordCount >= 50) lengthScore = 28;
  else if (wordCount >= 30) lengthScore = 22;
  else if (wordCount >= 15) lengthScore = 15;
  else lengthScore = 8;

  // Keyword score (up to 35 pts)
  const kwScore = Math.min(35, matchedKeywords.length * 9 + matchedStar.length * 3);

  // Structure score (up to 30 pts)
  const hasParagraphs = ans.includes('.') || ans.includes('\n');
  const structureScore = hasParagraphs ? 25 : 15;

  const totalScore = Math.min(96, Math.max(42, lengthScore + kwScore + structureScore));

  // Determine feedback
  let feedback = '';
  let strengths = '';
  let improvements = '';

  if (totalScore >= 80) {
    feedback = `Outstanding response! You demonstrated a deep understanding of ${role} fundamentals with precise technical vocabulary and clear logical structure.`;
    strengths = `Demonstrated strong conceptual grasp${matchedKeywords.length ? ` mentioning key principles like "${matchedKeywords.slice(0, 3).join(', ')}"` : ''}. Structured and confident delivery.`;
    improvements = `To make it even better for Senior rounds, quantify your impact with specific benchmarks, metrics, or trade-off comparisons.`;
  } else if (totalScore >= 60) {
    feedback = `Solid answer that addresses the core requirements. You have a good foundation, though expanding on practical trade-offs would strengthen your position.`;
    strengths = `Clear articulation of the primary concept and relevant context${matchedKeywords.length ? ` (identified ${matchedKeywords.slice(0, 2).join(', ')})` : ''}.`;
    improvements = `Add concrete real-world examples or address edge-cases and error handling to show deeper hands-on expertise.`;
  } else {
    feedback = `A fair initial attempt. However, the explanation is relatively brief and would benefit from more comprehensive technical detail and structure.`;
    strengths = `Addressed the central question directly without unnecessary filler.`;
    improvements = `Elaborate using the STAR method (Situation, Task, Action, Result). Mention specific tools, algorithms, or architectural patterns.`;
  }

  // Dynamic follow-up suggestion based on answer content
  let followUp = null;
  if (matchedKeywords.length > 0) {
    followUp = `You mentioned ${matchedKeywords[0]}. Could you elaborate on how you would handle edge cases or performance bottlenecks when scaling that?`;
  } else {
    followUp = `How would you apply this approach if you had strict constraints on latency or server resources?`;
  }

  return {
    score: totalScore,
    feedback,
    strengths,
    improvements,
    followUpSuggestion: followUp
  };
}

// ── Generate Question with Multi-Tier AI ─────────────────────
async function generateQuestion(index) {
  const previousQs = interview.questions
    .filter(Boolean)
    .map((q, i) => `Q${i+1}: ${q.text}`)
    .join('\n');

  const context = interview.answers.length > 0
    ? `\nThe candidate's last answer was: "${interview.answers[interview.answers.length - 1]?.text}"\n`
    : '';

  const prompt = `You are an expert ${config.type} interviewer conducting a ${config.difficulty} level interview for a ${config.role} position.
${previousQs ? `Previous questions asked:\n${previousQs}\n` : ''}${context}
Generate interview question #${index + 1} of ${interview.totalQ}.
- Ask a NEW, different question from previous ones.
- Match ${config.difficulty} difficulty.
- For ${config.type}: ${getTypeGuidance()}

Respond ONLY with valid JSON in this exact structure:
{"text": "The question text here", "category": "${config.type}", "hint": "A subtle hint"}`;

  try {
    const raw = await callAIEngine(prompt, "You are an interviewer. Return strictly a JSON object: {\"text\": \"...\", \"category\": \"...\", \"hint\": \"...\"}");
    const clean = raw.replace(/```json|```/g, '').trim();
    const json = JSON.parse(clean);
    if (json.text) return json;
  } catch (e) {
    console.log('Using curated question engine:', e.message);
  }

  // Curated role-specific dynamic question fallback
  return getFallbackQuestion(index, config.role, config.type, config.difficulty);
}

function getTypeGuidance() {
  const guides = {
    Technical:  'Focus on coding, algorithms, data structures, system design, and technical concepts.',
    HR:         'Focus on background, career goals, salary expectations, and company culture fit.',
    Behavioral: 'Use STAR format questions about past experiences, teamwork, and leadership.',
    Mixed:      'Alternate between technical skills and behavioral/HR questions.',
  };
  return guides[config.type] || guides.Technical;
}

// ── Evaluate Answer with Multi-Tier AI ───────────────────────
async function evaluateAnswer(question, answer) {
  if (!answer || answer.trim().length < 5) {
    return { score: 0, feedback: 'No answer provided.', strengths: '', improvements: 'Please provide a detailed answer to be evaluated.' };
  }

  const prompt = `You are an expert interviewer evaluating a candidate's answer.

Question: "${question}"
Candidate's Answer: "${answer}"
Job Role: ${config.role}
Difficulty: ${config.difficulty}
Interview Type: ${config.type}

Evaluate the answer and respond with ONLY a JSON object:
{
  "score": <number 0-100>,
  "feedback": "<2-3 sentence overall assessment>",
  "strengths": "<what the candidate did well>",
  "improvements": "<specific areas to improve>",
  "followUpSuggestion": "<a natural follow-up question or null>"
}`;

  try {
    const raw = await callAIEngine(prompt, "You are an AI interviewer evaluator. Return ONLY valid JSON: {\"score\": 85, \"feedback\": \"...\", \"strengths\": \"...\", \"improvements\": \"...\", \"followUpSuggestion\": \"...\"}");
    const clean = raw.replace(/```json|```/g, '').trim();
    const json = JSON.parse(clean);
    if (typeof json.score === 'number') return json;
  } catch (e) {
    // Intelligent built-in semantic evaluator (instant, realistic, and offline)
  }

  return semanticEvaluate(question, answer, config.role, config.difficulty, config.type);
}

// ── Submit Answer ─────────────────────────────────────────────
async function submitAnswer() {
  let answerText = '';
  const mode = config.mode || 'text';

  if (mode === 'text') {
    answerText = $('textAnswer')?.value?.trim() || '';
  } else if (mode === 'voice') {
    answerText = $('voiceTranscript')?.textContent?.trim() || '';
    if (answerText === 'Your speech will appear here as you speak...') answerText = '';
  } else {
    answerText = $('videoTranscript')?.textContent?.trim() || '';
  }

  if (!answerText) {
    alert('Please provide an answer before submitting.');
    return;
  }

  // Stop recording if active
  if (interview.isRecording) toggleRecording();

  // Add to transcript
  addTranscript('You', answerText);

  // Store answer
  interview.answers[interview.currentQ] = {
    text: answerText,
    questionIdx: interview.currentQ,
    timestamp: new Date().toISOString(),
  };

  // Show loading feedback state
  setAvatarStatus('speaking', 'Evaluating your answer...');
  $('answerArea').style.display = 'none';
  feedbackCard.style.display = 'block';
  feedbackScore.textContent = '...';
  feedbackContent.innerHTML = `<div class="question-loading"><div class="dot-pulse"><div class="dp-dot"></div><div class="dp-dot"></div><div class="dp-dot"></div></div><span>AI is evaluating...</span></div>`;

  // Get AI feedback
  const currentQuestion = interview.questions[interview.currentQ]?.text || 'Question';
  const evaluation = await evaluateAnswer(currentQuestion, answerText);

  // Store evaluation
  interview.answers[interview.currentQ].evaluation = evaluation;

  // Display feedback
  const scoreColor = evaluation.score >= 75 ? '#43e97b' : evaluation.score >= 50 ? '#ffb74d' : '#ef5350';
  feedbackScore.style.color = scoreColor;
  feedbackScore.textContent = evaluation.score + '%';

  feedbackContent.innerHTML = `
    <p>${evaluation.feedback}</p>
    ${evaluation.strengths ? `<div class="feedback-strength"><strong>✅ Strengths:</strong> ${evaluation.strengths}</div>` : ''}
    ${evaluation.improvements ? `<div class="feedback-improve"><strong>💡 Improve:</strong> ${evaluation.improvements}</div>` : ''}
  `;

  // Speak feedback summary
  speakText(evaluation.feedback);

  setAvatarStatus('waiting', 'Review your feedback');

  // Update next button text
  const isLast = interview.currentQ >= interview.totalQ - 1;
  $('nextQBtn').innerHTML = isLast
    ? '<i class="fas fa-flag-checkered"></i> Finish Interview'
    : 'Next Question <i class="fas fa-arrow-right"></i>';
}

// ── Load Next Question ────────────────────────────────────────
async function loadNextQuestion() {
  const next = interview.currentQ + 1;
  if (next >= interview.totalQ) { finalizeInterview(); return; }
  await loadQuestion(next);
}

// ── Request Hint ──────────────────────────────────────────────
async function requestHint() {
  const question = interview.questions[interview.currentQ];
  if (!question) return;

  const hintEl = $('questionHint');
  const hintText = $('hintText');
  hintText.textContent = question.hint || 'Think about the core concept behind this question and structure your answer using the STAR method (Situation, Task, Action, Result) for behavioral questions.';
  hintEl.style.display = 'flex';
}

// ── Question Timer ─────────────────────────────────────────────
function startQuestionTimer(limitSeconds) {
  clearInterval(interview.qTimer);
  if (limitSeconds <= 0) return;

  let remaining = limitSeconds;
  const timerEl = $('timerDisplay');

  interview.qTimer = setInterval(() => {
    remaining--;
    const m = String(Math.floor(remaining / 60)).padStart(2, '0');
    const s = String(remaining % 60).padStart(2, '0');
    if (remaining <= 30) timerEl.classList.add('warning');
    if (remaining <= 10) timerEl.classList.add('danger');
    if (remaining <= 0) {
      clearInterval(interview.qTimer);
      submitAnswer();
    }
  }, 1000);
}

// ── Text-to-Speech ─────────────────────────────────────────────
function speakText(text) {
  if (!window.speechSynthesis) return;

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);

  // Pick a good voice
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v => v.name.includes('Google') && v.lang.startsWith('en')) || voices[0];
  if (preferred) utterance.voice = preferred;
  utterance.rate = 0.9; utterance.pitch = 1.0; utterance.volume = 1.0;

  utterance.onstart = () => {
    $('avatarWrapper')?.classList.add('speaking');
    avatarMouth?.classList.add('talking');
    speakingInd?.classList.add('active');
    avatarGlow?.classList.add('speaking');
  };
  utterance.onend = () => {
    $('avatarWrapper')?.classList.remove('speaking');
    avatarMouth?.classList.remove('talking');
    speakingInd?.classList.remove('active');
    avatarGlow?.classList.remove('speaking');
  };

  window.speechSynthesis.speak(utterance);
}

// ── Speech Recognition ─────────────────────────────────────────
function setupSpeechRecognition(mode = 'voice') {
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRec) { console.warn('Speech Recognition not supported.'); return; }

  interview.recognition = new SpeechRec();
  interview.recognition.continuous  = true;
  interview.recognition.interimResults = true;
  interview.recognition.lang = 'en-US';

  const transcriptEl = $(mode === 'video' ? 'videoTranscript' : 'voiceTranscript');
  const submitBtn    = $(mode === 'video' ? null : 'submitVoiceBtn');

  let finalText = '';

  interview.recognition.onresult = (event) => {
    let interim = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) {
        finalText += event.results[i][0].transcript + ' ';
      } else {
        interim += event.results[i][0].transcript;
      }
    }
    if (transcriptEl) transcriptEl.innerHTML = `<p>${finalText}<span style="color:var(--text-muted)">${interim}</span></p>`;
    if (submitBtn) submitBtn.disabled = finalText.trim().length < 3;
  };

  interview.recognition.onerror = (e) => {
    if (e.error !== 'aborted') console.error('Speech error:', e.error);
  };
}

function toggleRecording() {
  if (!interview.recognition) {
    alert('Speech recognition is not supported in your browser. Please use Chrome or Edge.');
    return;
  }

  interview.isRecording = !interview.isRecording;
  const btn = $('recordBtn');

  if (interview.isRecording) {
    interview.recognition.start();
    btn?.classList.add('recording');
    $('recordBtnText').textContent = 'Recording... Click to Stop';
    setAvatarStatus('listening', 'Listening to your answer...');
    drawVoiceVisualizer();
  } else {
    interview.recognition.stop();
    btn?.classList.remove('recording');
    $('recordBtnText').textContent = 'Click to Speak';
  }
}

function toggleVideoRecording() {
  if (!interview.recognition) return;
  interview.isRecording = !interview.isRecording;
  const btn = $('videoRecBtn');
  if (interview.isRecording) {
    interview.recognition.start();
    $('videoRecText').textContent = 'Recording...';
    btn?.style.setProperty('border-color', 'rgba(239,83,80,0.6)');
  } else {
    interview.recognition.stop();
    $('videoRecText').textContent = 'Start Speaking';
  }
}

// ── Video Mode Setup ───────────────────────────────────────────
async function setupVideoMode() {
  try {
    interview.mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    const video = $('userVideo');
    if (video) video.srcObject = interview.mediaStream;
    setupSpeechRecognition('video');
  } catch (err) {
    alert('Camera/microphone access denied. Switching to text mode.');
    $('videoAnswerWrap').style.display = 'none';
    $('textAnswerWrap').style.display  = 'block';
  }
}

// ── Voice Visualizer ───────────────────────────────────────────
function drawVoiceVisualizer() {
  const canvas = $('voiceCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;

  if (!interview.audioContext && interview.mediaStream) {
    interview.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const source = interview.audioContext.createMediaStreamSource(interview.mediaStream);
    interview.analyser = interview.audioContext.createAnalyser();
    interview.analyser.fftSize = 64;
    source.connect(interview.analyser);
  }

  function draw() {
    if (!interview.isRecording) { ctx.clearRect(0,0,W,H); return; }
    requestAnimationFrame(draw);
    ctx.clearRect(0,0,W,H);

    if (interview.analyser) {
      const data = new Uint8Array(interview.analyser.frequencyBinCount);
      interview.analyser.getByteFrequencyData(data);
      const barW = W / data.length;
      data.forEach((v, i) => {
        const h = (v / 255) * H;
        const alpha = 0.5 + (i / data.length) * 0.5;
        ctx.fillStyle = `rgba(108,99,255,${alpha})`;
        ctx.fillRect(i * barW, H - h, barW - 1, h);
      });
    } else {
      // Fake visualizer
      for (let i = 0; i < 20; i++) {
        const h = Math.random() * H * 0.6 + 10;
        ctx.fillStyle = `rgba(108,99,255,${0.4 + Math.random() * 0.5})`;
        ctx.fillRect(i * (W/20), H - h, W/20 - 2, h);
      }
    }
  }
  draw();
}

// ── Transcript ─────────────────────────────────────────────────
function addTranscript(speaker, text) {
  interview.transcript.push({ speaker, text, time: new Date().toLocaleTimeString() });

  const entryClass = speaker === 'AI' ? 'ai' : 'user';
  const entry = `<div class="transcript-entry ${entryClass}"><strong>${speaker}:</strong> ${text}</div>`;

  if (miniTranscript) { miniTranscript.innerHTML += entry; miniTranscript.scrollTop = miniTranscript.scrollHeight; }
  if (transcriptFull) { transcriptFull.innerHTML += entry; transcriptFull.scrollTop = transcriptFull.scrollHeight; }
}

function toggleFullTranscript() {
  const modal = $('transcriptModal');
  modal?.classList.toggle('open');
}

// ── Avatar Status ──────────────────────────────────────────────
function setAvatarStatus(state, text) {
  if (statusText) statusText.textContent = text;
  if (statusDot) {
    statusDot.className = 'status-dot ' + state;
  }
}

// ── Word Count ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const ta = $('textAnswer');
  if (ta) {
    ta.addEventListener('input', () => {
      const words = ta.value.trim().split(/\s+/).filter(Boolean).length;
      $('wordCount').textContent = words + ' word' + (words !== 1 ? 's' : '');
    });
  }
});

// ── End Interview ──────────────────────────────────────────────
function endInterview() { $('endModal')?.classList.add('open'); }
function closeEndModal() { $('endModal')?.classList.remove('open'); }

function finalizeInterview() {
  // Stop all media
  if (interview.mediaStream) interview.mediaStream.getTracks().forEach(t => t.stop());
  window.speechSynthesis?.cancel();
  if (interview.recognition) interview.recognition.stop();

  // Calculate overall score
  const scores = interview.answers.map(a => a?.evaluation?.score || 0).filter(s => s > 0);
  const avgScore = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : 0;
  const duration = Math.floor((Date.now() - interview.startTime) / 60000);

  // Save to history
  const history = JSON.parse(localStorage.getItem('aiInterviewHistory') || '[]');
  history.unshift({
    id: Date.now(),
    role: config.role,
    type: config.type,
    difficulty: config.difficulty,
    mode: config.mode,
    score: avgScore,
    date: new Date().toISOString(),
    duration: duration + ' min',
    questions: interview.questions.length,
    answers: interview.answers,
    transcript: interview.transcript,
  });
  localStorage.setItem('aiInterviewHistory', JSON.stringify(history));

  // Update stats
  const stats = JSON.parse(localStorage.getItem('aiInterviewStats') || '{"total":0,"avgScore":0,"hours":0,"streak":0}');
  stats.total += 1;
  stats.hours  = Math.round((stats.hours + duration / 60) * 10) / 10;
  stats.avgScore = Math.round(((stats.avgScore * (stats.total - 1)) + avgScore) / stats.total);
  stats.streak += 1;
  localStorage.setItem('aiInterviewStats', JSON.stringify(stats));

  // Save result for report page
  sessionStorage.setItem('lastInterviewResult', JSON.stringify({
    config, avgScore, duration, interview
  }));

  window.location.href = 'report.html';
}

// ── Fallback Questions (Role & Level Tailored) ─────────────────
function getFallbackQuestion(index, role, type, difficulty) {
  const roleBanks = {
    'Frontend Developer': {
      Technical: [
        { text: 'Explain the difference between Virtual DOM and Real DOM in modern web frameworks.', category: 'Architecture', hint: 'Think about reconciliation and browser reflow performance.' },
        { text: 'What is the JavaScript Event Loop, Call Stack, Microtask queue, and Macrotask queue?', category: 'Core JavaScript', hint: 'Compare Promise resolution priority vs setTimeout.' },
        { text: 'Explain CSS Flexbox vs CSS Grid. When would you choose one over the other?', category: 'CSS & Layout', hint: '1D component alignment vs 2D page-level grid systems.' },
        { text: 'How do you optimize the loading and rendering performance of a Single Page Application?', category: 'Performance', hint: 'Mention code-splitting, lazy loading, caching, and tree-shaking.' },
        { text: 'What are React Hooks lifecycle equivalents? Explain useEffect and its dependency array.', category: 'React', hint: 'Consider mount, update, and unmount cleanup phases.' }
      ]
    },
    'Python Developer': {
      Technical: [
        { text: 'Explain Python decorators, closures, and how the @ syntax works under the hood.', category: 'Advanced Python', hint: 'Functions as first-class citizens taking and returning functions.' },
        { text: 'What is the Global Interpreter Lock (GIL) and how does it impact multi-threaded CPU tasks?', category: 'Python Internals', hint: 'Contrast multi-threading with multiprocessing for CPU vs I/O.' },
        { text: 'What is the difference between list comprehensions and generators in terms of memory?', category: 'Memory & Performance', hint: 'Eager memory allocation vs lazy yield evaluation.' },
        { text: 'How does Python manage memory and garbage collection? Explain reference counting.', category: 'Memory', hint: 'Mention reference counting and cyclical garbage collection.' },
        { text: 'Explain how you structure a scalable Python backend using FastAPI or Django.', category: 'Frameworks', hint: 'Consider routing, dependency injection, ORM, and async endpoints.' }
      ]
    },
    'Data Analyst': {
      Technical: [
        { text: 'Explain the difference between INNER JOIN, LEFT JOIN, and FULL OUTER JOIN in SQL.', category: 'SQL', hint: 'Consider how unmatched rows from left or right tables are handled.' },
        { text: 'How do you detect and treat missing data, outliers, and skewed distributions in a dataset?', category: 'Data Wrangling', hint: 'Discuss imputation techniques, z-score, IQR, and log transforms.' },
        { text: 'What is the Central Limit Theorem and why is it foundational to A/B testing?', category: 'Statistics', hint: 'Think about sample means approaching normal distribution.' },
        { text: 'Explain the difference between OLAP and OLTP systems and their database designs.', category: 'Data Warehousing', hint: 'Analytical read-heavy queries vs transactional ACID write queries.' },
        { text: 'How do you choose between Mean, Median, and Mode when reporting executive business metrics?', category: 'Business Metrics', hint: 'Explain susceptibility to outliers and skewed distributions.' }
      ]
    },
    'Software Developer': {
      Technical: [
        { text: 'Explain the difference between process and thread. How does context switching work?', category: 'Operating Systems', hint: 'Think about shared memory space and CPU scheduling.' },
        { text: 'What are the SOLID design principles? Give an example of Single Responsibility Principle.', category: 'Software Design', hint: 'A class should have only one reason to change.' },
        { text: 'Explain RESTful API architecture. What are the key HTTP methods and idempotency rules?', category: 'API Design', hint: 'PUT vs POST vs PATCH idempotency differences.' },
        { text: 'Compare the time and space complexity of QuickSort, MergeSort, and HeapSort.', category: 'Algorithms', hint: 'Consider worst-case, average-case, and stability requirements.' },
        { text: 'How would you design a distributed caching layer using Redis for high read traffic?', category: 'System Design', hint: 'Cache-aside pattern, eviction policies (LRU), and TTL.' }
      ]
    }
  };

  const generalHR = [
    { text: 'Tell me about yourself, your technical background, and your career milestones.', category: 'Introduction', hint: 'Past experience, present skills, and future aspirations.' },
    { text: 'Why are you specifically interested in this position and what value will you bring to our team?', category: 'Motivation', hint: 'Align your technical strengths with company vision.' },
    { text: 'Where do you see yourself developing professionally in the next 3 to 5 years?', category: 'Career Vision', hint: 'Show ambition for technical mastery and leadership.' },
    { text: 'What are your greatest technical strengths, and one area you are currently striving to improve?', category: 'Self-Awareness', hint: 'Demonstrate self-awareness and how you actively learn.' }
  ];

  const generalBehavioral = [
    { text: 'Tell me about a time you faced a difficult technical bug under a tight deadline. How did you resolve it?', category: 'Problem Solving', hint: 'Use STAR: Situation, Task, Action, and Result.' },
    { text: 'Describe a situation where you had a disagreement with a teammate over technical architecture. How did you reach consensus?', category: 'Collaboration', hint: 'Focus on constructive communication and objective evaluation.' },
    { text: 'Can you share an experience where a project requirement changed unexpectedly midway through development?', category: 'Adaptability', hint: 'Highlight agile adaptability and stakeholder alignment.' },
    { text: 'Tell me about a project you are most proud of. What architectural decisions did you make?', category: 'Ownership', hint: 'Explain trade-offs, technologies chosen, and measured outcome.' }
  ];

  if (type === 'HR') {
    return generalHR[index % generalHR.length];
  }
  if (type === 'Behavioral') {
    return generalBehavioral[index % generalBehavioral.length];
  }
  if (type === 'Mixed') {
    const mixed = index % 2 === 0
      ? (roleBanks[role]?.Technical || roleBanks['Software Developer'].Technical)
      : generalBehavioral;
    return mixed[Math.floor(index / 2) % mixed.length];
  }

  // Technical
  const techList = (roleBanks[role] && roleBanks[role].Technical) || roleBanks['Software Developer'].Technical;
  return techList[index % techList.length];
}
