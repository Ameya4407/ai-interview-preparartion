// ============================================================
// InterviewAI – Authentication JavaScript
// ============================================================

// Toggle password visibility
function setupPasswordToggle(inputId, toggleId) {
  const input = document.getElementById(inputId);
  const toggle = document.getElementById(toggleId);
  if (input && toggle) {
    toggle.addEventListener('click', () => {
      const isText = input.type === 'text';
      input.type = isText ? 'password' : 'text';
      toggle.querySelector('i').className = isText ? 'fas fa-eye' : 'fas fa-eye-slash';
    });
  }
}
setupPasswordToggle('password', 'togglePwd');

// Password strength checker
const pwdInput = document.getElementById('password');
if (pwdInput && document.getElementById('strengthFill')) {
  pwdInput.addEventListener('input', () => {
    const val = pwdInput.value;
    const fill = document.getElementById('strengthFill');
    const label = document.getElementById('strengthLabel');
    let score = 0;
    if (val.length >= 8)  score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;

    const levels = [
      { w: '25%', color: '#ef5350', text: 'Weak' },
      { w: '50%', color: '#FF9800', text: 'Fair' },
      { w: '75%', color: '#FFC107', text: 'Good' },
      { w: '100%', color: '#4CAF50', text: 'Strong' },
    ];
    if (val.length === 0) { fill.style.width = '0'; label.textContent = ''; return; }
    const lvl = levels[Math.min(score - 1, 3)] || levels[0];
    fill.style.width = lvl.w;
    fill.style.background = lvl.color;
    label.textContent = lvl.text;
    label.style.color = lvl.color;
  });
}

// Show error helper
function showError(elId, msg) {
  const el = document.getElementById(elId);
  if (el) { el.textContent = msg; }
}
function clearErrors() {
  document.querySelectorAll('.field-error').forEach(el => el.textContent = '');
  const alert = document.getElementById('authError');
  if (alert) { alert.textContent = ''; alert.classList.add('hidden'); }
}
function showAlert(msg) {
  const alert = document.getElementById('authError');
  if (alert) { alert.textContent = msg; alert.classList.remove('hidden'); }
}

// Set button loading state
function setLoading(btnId, loading) {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  btn.disabled = loading;
  btn.querySelector('.btn-text').style.display = loading ? 'none' : '';
  btn.querySelector('.btn-loader').classList.toggle('hidden', !loading);
}

// ── Handle Login ─────────────────────────────────────────────
async function handleLogin() {
  clearErrors();
  const email    = document.getElementById('email')?.value.trim();
  const password = document.getElementById('password')?.value;

  let valid = true;
  if (!email || !/\S+@\S+\.\S+/.test(email)) {
    showError('emailErr', 'Please enter a valid email address.'); valid = false;
  }
  if (!password || password.length < 6) {
    showError('pwdErr', 'Password must be at least 6 characters.'); valid = false;
  }
  if (!valid) return;

  setLoading('loginBtn', true);

  try {
    const res = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (res.ok && data.token) {
      localStorage.setItem('aiInterviewToken', data.token);
      localStorage.setItem('aiInterviewUser', JSON.stringify(data.user));
      window.location.href = 'dashboard.html';
    } else {
      showAlert(data.message || 'Invalid credentials. Please try again.');
    }
  } catch {
    // Demo mode – bypass network
    const demoUser = { id: 'demo', name: 'Demo User', email, role: 'Software Developer', level: 'Intermediate' };
    localStorage.setItem('aiInterviewToken', 'demo_token_' + Date.now());
    localStorage.setItem('aiInterviewUser', JSON.stringify(demoUser));
    window.location.href = 'dashboard.html';
  } finally {
    setLoading('loginBtn', false);
  }
}

// ── Handle Register ───────────────────────────────────────────
async function handleRegister() {
  clearErrors();
  const firstName  = document.getElementById('firstName')?.value.trim();
  const lastName   = document.getElementById('lastName')?.value.trim();
  const email      = document.getElementById('email')?.value.trim();
  const jobRole    = document.getElementById('jobRole')?.value;
  const experience = document.getElementById('experience')?.value;
  const password   = document.getElementById('password')?.value;
  const confirm    = document.getElementById('confirmPassword')?.value;
  const terms      = document.getElementById('terms')?.checked;

  let valid = true;
  if (!firstName) { showError('firstNameErr', 'First name is required.'); valid = false; }
  if (!email || !/\S+@\S+\.\S+/.test(email)) { showError('emailErr', 'Valid email required.'); valid = false; }
  if (!password || password.length < 8) { showError('pwdErr', 'Password must be 8+ characters.'); valid = false; }
  if (password !== confirm) { showError('confirmPwdErr', 'Passwords do not match.'); valid = false; }
  if (!terms) { showAlert('Please accept the Terms of Service to continue.'); valid = false; }
  if (!valid) return;

  setLoading('registerBtn', true);

  const payload = { firstName, lastName, email, password, jobRole, experience };

  try {
    const res = await fetch('http://localhost:5000/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (res.ok && data.token) {
      localStorage.setItem('aiInterviewToken', data.token);
      localStorage.setItem('aiInterviewUser', JSON.stringify(data.user));
      window.location.href = 'dashboard.html';
    } else {
      showAlert(data.message || 'Registration failed. Please try again.');
    }
  } catch {
    // Demo mode
    const demoUser = { id: 'demo', name: `${firstName} ${lastName}`, email, role: jobRole || 'Software Developer', level: experience || 'Beginner' };
    localStorage.setItem('aiInterviewToken', 'demo_token_' + Date.now());
    localStorage.setItem('aiInterviewUser', JSON.stringify(demoUser));
    window.location.href = 'dashboard.html';
  } finally {
    setLoading('registerBtn', false);
  }
}

function googleAuth() { alert('Google OAuth coming soon! Currently in demo mode.'); }
function githubAuth() { alert('GitHub OAuth coming soon! Currently in demo mode.'); }
