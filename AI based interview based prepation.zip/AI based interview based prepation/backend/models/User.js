// ============================================================
// InterviewAI – User Model (MongoDB/Mongoose)
// ============================================================

const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const userSchema = new mongoose.Schema({
  firstName:   { type: String, required: true, trim: true },
  lastName:    { type: String, required: true, trim: true },
  email:       { type: String, required: true, unique: true, lowercase: true, trim: true },
  password:    { type: String, required: true, minlength: 6 },
  avatar:      { type: String, default: null },
  
  // Professional Info
  jobRole:     { type: String, default: 'Software Developer' },
  experience:  { type: String, default: 'Beginner' },
  skills:      [{ type: String }],
  targetDate:  { type: Date },
  
  // Resume
  resumeUrl:   { type: String, default: null },
  atsScore:    { type: Number, default: null },
  
  // Stats
  totalInterviews: { type: Number, default: 0 },
  avgScore:        { type: Number, default: 0 },
  practiceHours:   { type: Number, default: 0 },
  streak:          { type: Number, default: 0 },
  lastActiveDate:  { type: Date, default: Date.now },
  
  // Settings
  preferredMode:   { type: String, enum: ['text','voice','video'], default: 'voice' },
  notifications:   { type: Boolean, default: true },
  
  // Auth
  isActive:    { type: Boolean, default: true },
  isVerified:  { type: Boolean, default: false },
  createdAt:   { type: Date, default: Date.now },
  updatedAt:   { type: Date, default: Date.now },
}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Return safe user object (no password)
userSchema.methods.toSafeObject = function() {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
