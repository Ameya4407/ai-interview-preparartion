// ============================================================
// InterviewAI – Database Configuration (MongoDB + MySQL support)
// ============================================================

const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/interviewai';
    
    const conn = await mongoose.connect(mongoURI, {
      useNewUrlParser:    true,
      useUnifiedTopology: true,
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error('❌ MongoDB Connection Error:', error.message);
    console.log('💡 Tip: Make sure MongoDB is running. Using in-memory mode for development.');
    // Don't exit – allow demo mode without DB
  }
};

module.exports = connectDB;
