// ============================================================
// InterviewAI – Interview Session Model
// ============================================================

const mongoose = require('mongoose');

const answerSchema = new mongoose.Schema({
  questionIndex: Number,
  questionText:  String,
  answerText:    String,
  score:         Number,
  feedback:      String,
  strengths:     String,
  improvements:  String,
  timestamp:     { type: Date, default: Date.now },
});

const transcriptEntrySchema = new mongoose.Schema({
  speaker:   { type: String, enum: ['AI', 'User'] },
  text:      String,
  timestamp: Date,
});

const interviewSessionSchema = new mongoose.Schema({
  userId:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  
  // Config
  role:       { type: String, required: true },
  difficulty: { type: String, enum: ['Beginner', 'Intermediate', 'Advanced'] },
  type:       { type: String, enum: ['Technical', 'HR', 'Behavioral', 'Mixed'] },
  mode:       { type: String, enum: ['text', 'voice', 'video'] },
  
  // Questions & Answers
  questions:  [{ text: String, category: String, hint: String }],
  answers:    [answerSchema],
  transcript: [transcriptEntrySchema],
  
  // Results
  totalQuestions: { type: Number, default: 0 },
  answeredCount:  { type: Number, default: 0 },
  avgScore:       { type: Number, default: 0 },
  
  // Skill scores (0-100)
  scores: {
    technical:    { type: Number, default: 0 },
    communication:{ type: Number, default: 0 },
    confidence:   { type: Number, default: 0 },
    clarity:      { type: Number, default: 0 },
    problemSolving:{ type: Number, default: 0 },
  },
  
  // Meta
  startedAt:  { type: Date, default: Date.now },
  endedAt:    Date,
  duration:   Number, // minutes
  status:     { type: String, enum: ['active', 'completed', 'abandoned'], default: 'active' },
  
  // AI Summary
  aiSummary:    String,
  keyStrengths: [String],
  areasToImprove: [String],
  
  // Bookmarked
  isBookmarked: { type: Boolean, default: false },
  
  reportUrl:  String,
}, { timestamps: true });

// Auto-calculate avgScore before saving
interviewSessionSchema.pre('save', function(next) {
  if (this.answers && this.answers.length > 0) {
    const scores = this.answers.map(a => a.score || 0).filter(s => s > 0);
    this.avgScore = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : 0;
    this.answeredCount = this.answers.filter(a => a.answerText).length;
  }
  next();
});

module.exports = mongoose.model('InterviewSession', interviewSessionSchema);
