// ============================================================
// InterviewAI – Gemini AI Routes (Question Gen + Evaluation)
// ============================================================

const router = require('express').Router();
const authMW = require('../middleware/auth');
const axios  = require('axios');

const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

async function callGemini(prompt, temperature = 0.8) {
  const apiKey = process.env.GEMINI_API_KEY;

  // 1. Try Google Gemini if key is provided
  if (apiKey && apiKey !== 'your_gemini_api_key_here') {
    try {
      const response = await axios.post(`${GEMINI_BASE}?key=${apiKey}`, {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature, maxOutputTokens: 1024 },
      });
      const text = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (text) return text;
    } catch (e) {
      console.warn('[Gemini API] Failed, switching to Free Public AI provider:', e.message);
    }
  }

  // 2. Free Public Cloud LLM (Pollinations AI - 100% Free, No Key Required)
  try {
    const res = await axios.post('https://text.pollinations.ai/', {
      messages: [
        { role: 'system', content: 'You are an expert AI interviewer. Output strictly valid JSON.' },
        { role: 'user', content: prompt }
      ],
      model: 'openai',
      jsonMode: true
    }, { timeout: 10000 });

    if (res.data) {
      return typeof res.data === 'string' ? res.data : JSON.stringify(res.data);
    }
  } catch (e) {
    console.warn('[Free Public AI] Request timed out or failed:', e.message);
  }

  throw new Error('AI providers unavailable. Check network connectivity or configure GEMINI_API_KEY in .env.');
}

// ── POST /api/gemini/generate-question ───────────────────────
router.post('/generate-question', authMW, async (req, res) => {
  const { role, difficulty, type, questionNumber, totalQuestions, previousQuestions, lastAnswer } = req.body;

  const prevQText = previousQuestions?.map((q, i) => `Q${i+1}: ${q.text}`).join('\n') || '';
  const lastAnsContext = lastAnswer ? `\nCandidate's last answer: "${lastAnswer}"\n` : '';

  const prompt = `You are an expert ${type} interviewer for a ${role} position.
${prevQText ? `Previous questions asked:\n${prevQText}\n` : ''}${lastAnsContext}
Generate interview question #${questionNumber} of ${totalQuestions} at ${difficulty} difficulty.
${questionNumber > Math.floor(totalQuestions/2) && lastAnswer ? 'Ask a relevant follow-up based on the candidate\'s previous answer.' : ''}

Type guidance:
- Technical: DSA, system design, frameworks, debugging, architecture
- HR: background, motivation, salary, culture fit
- Behavioral: STAR format, teamwork, leadership, conflict resolution
- Mixed: rotate between above types

Respond ONLY with valid JSON:
{"text": "question here", "category": "category here", "hint": "subtle hint for candidate"}`;

  try {
    const raw  = await callGemini(prompt, 0.8);
    const json = JSON.parse(raw.replace(/```json|```/g, '').trim());
    res.json({ question: json });
  } catch (err) {
    console.error('[Gemini Question Gen]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/gemini/evaluate-answer ─────────────────────────
router.post('/evaluate-answer', authMW, async (req, res) => {
  const { question, answer, role, difficulty, type } = req.body;

  if (!answer || answer.trim().length < 5) {
    return res.json({
      evaluation: { score: 0, feedback: 'No meaningful answer provided.', strengths: '', improvements: 'Please provide a detailed answer.' }
    });
  }

  const prompt = `You are an expert ${type} interviewer evaluating a candidate for a ${role} position.

Question: "${question}"
Candidate Answer: "${answer}"
Difficulty: ${difficulty}

Evaluate thoroughly and respond ONLY with valid JSON:
{
  "score": <0-100>,
  "feedback": "<2-3 sentence overall assessment>",
  "strengths": "<specific strong points of the answer>",
  "improvements": "<actionable areas to improve>",
  "followUpSuggestion": "<optional follow-up question or null>",
  "communicationScore": <0-100>,
  "technicalScore": <0-100>,
  "clarityScore": <0-100>
}`;

  try {
    const raw  = await callGemini(prompt, 0.4);
    const json = JSON.parse(raw.replace(/```json|```/g, '').trim());
    res.json({ evaluation: json });
  } catch (err) {
    console.error('[Gemini Eval]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/gemini/analyze-resume ──────────────────────────
router.post('/analyze-resume', authMW, async (req, res) => {
  const { resumeText, targetRole } = req.body;

  const prompt = `You are an expert ATS (Applicant Tracking System) and HR professional.
Analyze the following resume for a ${targetRole} position:

${resumeText.substring(0, 3000)}

Respond ONLY with valid JSON:
{
  "atsScore": <0-100>,
  "overallScore": <0-100>,
  "summary": "<brief overall assessment>",
  "strengths": ["strength1", "strength2", "strength3"],
  "weaknesses": ["weakness1", "weakness2"],
  "missingKeywords": ["keyword1", "keyword2", "keyword3"],
  "suggestions": ["suggestion1", "suggestion2", "suggestion3"],
  "sectionScores": {
    "experience": <0-100>,
    "skills": <0-100>,
    "education": <0-100>,
    "formatting": <0-100>
  },
  "interviewQuestions": ["question based on resume 1", "question based on resume 2", "question based on resume 3"]
}`;

  try {
    const raw  = await callGemini(prompt, 0.3);
    const json = JSON.parse(raw.replace(/```json|```/g, '').trim());
    res.json({ analysis: json });
  } catch (err) {
    console.error('[Gemini Resume]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/gemini/generate-study-plan ─────────────────────
router.post('/generate-study-plan', authMW, async (req, res) => {
  const { role, level, targetDate, weakAreas } = req.body;

  const daysLeft = Math.ceil((new Date(targetDate) - new Date()) / (1000 * 60 * 60 * 24));

  const prompt = `Create a personalized interview study plan for a ${level} ${role} candidate.
Days until interview: ${daysLeft}
Weak areas identified: ${weakAreas?.join(', ') || 'None specified'}

Respond ONLY with valid JSON:
{
  "overview": "<brief plan summary>",
  "weeks": [
    {
      "week": 1,
      "focus": "<main topic>",
      "dailyTasks": [
        {"day": "Monday", "task": "task description", "duration": "30 min"},
        ...
      ]
    }
  ],
  "resources": [
    {"title": "resource name", "type": "book/video/article", "url": "link or null"}
  ],
  "tips": ["tip1", "tip2", "tip3"]
}`;

  try {
    const raw  = await callGemini(prompt, 0.5);
    const json = JSON.parse(raw.replace(/```json|```/g, '').trim());
    res.json({ plan: json });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/gemini/chat ─────────────────────────────────────
router.post('/chat', authMW, async (req, res) => {
  const { message, context } = req.body;

  const prompt = `You are InterviewAI's helpful assistant. ${context || ''}
User message: "${message}"
Give a helpful, concise response about interview preparation, career advice, or the platform.`;

  try {
    const response = await callGemini(prompt, 0.7);
    res.json({ response });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
