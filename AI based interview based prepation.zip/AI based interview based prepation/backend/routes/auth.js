// ============================================================
// InterviewAI – Auth Routes (Register / Login)
// ============================================================

const router  = require('express').Router();
const jwt     = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');

const generateToken = (userId) => jwt.sign(
  { id: userId },
  process.env.JWT_SECRET || 'fallback_secret',
  { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
);

// ── POST /api/auth/register ───────────────────────────────────
router.post('/register',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
    body('firstName').notEmpty().trim().withMessage('First name required'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ message: errors.array()[0].msg });

    const { firstName, lastName, email, password, jobRole, experience } = req.body;

    try {
      const existing = await User.findOne({ email });
      if (existing) return res.status(409).json({ message: 'An account with this email already exists.' });

      const user = await User.create({ firstName, lastName, email, password, jobRole, experience });
      const token = generateToken(user._id);

      res.status(201).json({
        message: 'Registration successful!',
        token,
        user: user.toSafeObject(),
      });
    } catch (err) {
      console.error('[Register]', err.message);
      res.status(500).json({ message: 'Registration failed. Please try again.' });
    }
  }
);

// ── POST /api/auth/login ──────────────────────────────────────
router.post('/login',
  [
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ message: 'Invalid email or password.' });

    const { email, password } = req.body;

    try {
      const user = await User.findOne({ email });
      if (!user) return res.status(401).json({ message: 'No account found with this email.' });

      const isMatch = await user.comparePassword(password);
      if (!isMatch) return res.status(401).json({ message: 'Incorrect password. Please try again.' });

      // Update last active
      user.lastActiveDate = new Date();
      await user.save();

      const token = generateToken(user._id);
      res.json({ message: 'Login successful!', token, user: user.toSafeObject() });
    } catch (err) {
      console.error('[Login]', err.message);
      res.status(500).json({ message: 'Login failed. Please try again.' });
    }
  }
);

// ── GET /api/auth/me ──────────────────────────────────────────
const authMW = require('../middleware/auth');
router.get('/me', authMW, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found.' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching user.' });
  }
});

module.exports = router;
