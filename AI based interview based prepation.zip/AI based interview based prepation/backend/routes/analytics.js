// ============================================================
// InterviewAI – Analytics Routes
// ============================================================

const router  = require('express').Router();
const authMW  = require('../middleware/auth');
const InterviewSession = require('../models/InterviewSession');

// GET /api/analytics/overview
router.get('/overview', authMW, async (req, res) => {
  try {
    const userId = req.user.id;
    const sessions = await InterviewSession.find({ userId, status: 'completed' }).select('avgScore scores duration createdAt role type');

    const total      = sessions.length;
    const avgScore   = total ? Math.round(sessions.reduce((s,i)=>s+i.avgScore,0)/total) : 0;
    const totalHours = Math.round(sessions.reduce((s,i)=>s+(i.duration||0),0)/60*10)/10;

    // Score trend (last 10)
    const trend = sessions.slice(-10).map(s => ({
      date:  s.createdAt,
      score: s.avgScore,
      role:  s.role,
    }));

    // Role distribution
    const roleMap = {};
    sessions.forEach(s => { roleMap[s.role] = (roleMap[s.role]||0)+1; });

    // Type distribution
    const typeMap = {};
    sessions.forEach(s => { typeMap[s.type] = (typeMap[s.type]||0)+1; });

    // Skill averages
    const skillKeys = ['technical','communication','confidence','clarity','problemSolving'];
    const skillAvgs = {};
    skillKeys.forEach(k => {
      const vals = sessions.map(s=>s.scores?.[k]||0).filter(v=>v>0);
      skillAvgs[k] = vals.length ? Math.round(vals.reduce((a,b)=>a+b,0)/vals.length) : 0;
    });

    res.json({ total, avgScore, totalHours, trend, roleDistribution: roleMap, typeDistribution: typeMap, skillAverages: skillAvgs });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
